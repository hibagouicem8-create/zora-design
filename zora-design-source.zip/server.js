const express = require('express');
const session = require('express-session');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'store.json');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
if (!fs.existsSync(DB_FILE)) {
  const initial = {
    products: [
      {id:1,name:"Ceinture Perles Nacrées",category:"Accessoires",description:"Perles nacrées et boucle dorée.",price:3500,image:"https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=900&q=85",featured:true},
      {id:2,name:"Pochette Dorée Zora",category:"Accessoires",description:"Une touche lumineuse pour vos soirées.",price:4800,image:"https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=900&q=85",featured:true},
      {id:3,name:"Blouse Coton Ivoire",category:"Blouses",description:"Une blouse douce et intemporelle.",price:5200,image:"https://images.unsplash.com/photo-1551163943-3f6a855d1153?auto=format&fit=crop&w=900&q=85",featured:true},
      {id:4,name:"Blouse Soie Rosée",category:"Blouses",description:"Une silhouette délicate et raffinée.",price:6500,image:"https://images.unsplash.com/photo-1566206091558-7f218b696731?auto=format&fit=crop&w=900&q=85",featured:true},
      {id:5,name:"Jupe Satin Blush",category:"Jupes",description:"Satin élégant, mouvement fluide.",price:6800,image:"https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=900&q=85",featured:true},
      {id:6,name:"Jupe Plissée Champagne",category:"Jupes",description:"Une pièce légère pour vos occasions.",price:7200,image:"https://images.unsplash.com/photo-1582142306909-195724d33ffc?auto=format&fit=crop&w=900&q=85",featured:true},
      {id:7,name:"Blouza Traditionnelle",category:"Robes",description:"L'esprit du patrimoine revisité avec élégance.",price:14500,image:"https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=900&q=85",featured:false},
      {id:8,name:"Karakou Velours",category:"Costumes",description:"Velours et détails inspirés de l'artisanat.",price:28000,image:"https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=900&q=85",featured:false},
      {id:9,name:"Caftan de Cérémonie",category:"Caftans",description:"Une tenue raffinée pour les grands moments.",price:32000,image:"https://images.unsplash.com/photo-1596783074918-c84cb06531ca?auto=format&fit=crop&w=900&q=85",featured:false}
    ],
    orders: [],
    subscribers: []
  };
  fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
}
const readDB = () => JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
const writeDB = db => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || 'dev-only-change-me',
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:8*60*60*1000}
}));
app.use(express.static(path.join(__dirname,'public')));
app.use('/api', rateLimit({windowMs:15*60*1000, max:150}));

const clean = v => String(v ?? '').trim();
const adminOnly = (req,res,next) => req.session.admin ? next() : res.status(401).json({error:'Authentification requise.'});

app.get('/api/products',(req,res)=>{
  const db=readDB();
  const category=clean(req.query.category);
  let products=db.products;
  if(category && category!=='Tous') products=products.filter(p=>p.category===category);
  res.json(products);
});
app.get('/api/products/:id',(req,res)=>{
  const p=readDB().products.find(x=>x.id===Number(req.params.id));
  p ? res.json(p) : res.status(404).json({error:'Produit introuvable.'});
});
app.post('/api/orders',(req,res)=>{
  const {customer,items}=req.body || {};
  if(!customer || !clean(customer.name) || !clean(customer.phone) || !clean(customer.address) || !Array.isArray(items) || !items.length)
    return res.status(400).json({error:'Veuillez remplir les informations et ajouter un article.'});
  const db=readDB();
  const orderItems=[];
  for(const item of items){
    const product=db.products.find(p=>p.id===Number(item.id));
    const qty=Math.max(1,Math.min(20,Number(item.quantity)||1));
    if(product) orderItems.push({id:product.id,name:product.name,price:product.price,quantity:qty});
  }
  if(!orderItems.length) return res.status(400).json({error:'Aucun produit valide.'});
  const total=orderItems.reduce((s,i)=>s+i.price*i.quantity,0);
  const order={id:Date.now(),customer:{name:clean(customer.name),phone:clean(customer.phone),address:clean(customer.address),note:clean(customer.note)},items:orderItems,total,status:'Nouvelle',createdAt:new Date().toISOString()};
  db.orders.unshift(order); writeDB(db);
  res.status(201).json({message:'Commande enregistrée.',order});
});
app.post('/api/newsletter',(req,res)=>{
  const email=clean(req.body.email).toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:'Adresse e-mail invalide.'});
  const db=readDB();
  if(!db.subscribers.includes(email)) db.subscribers.push(email);
  writeDB(db); res.json({message:'Merci pour votre inscription !'});
});
app.post('/api/admin/login',(req,res)=>{
  const username=process.env.ADMIN_USERNAME||'admin';
  const password=process.env.ADMIN_PASSWORD||'ChangeThisPassword123!';
  if(clean(req.body.username)!==username || !bcrypt.compareSync(clean(req.body.password), bcrypt.hashSync(password, 10)) && clean(req.body.password)!==password)
    return res.status(401).json({error:'Identifiants incorrects.'});
  req.session.admin=true; res.json({message:'Connexion réussie.'});
});
app.post('/api/admin/logout',adminOnly,(req,res)=>req.session.destroy(()=>res.json({message:'Déconnecté.'})));
app.get('/api/admin/orders',adminOnly,(req,res)=>res.json(readDB().orders));
app.patch('/api/admin/orders/:id',adminOnly,(req,res)=>{
  const db=readDB(), order=db.orders.find(o=>o.id===Number(req.params.id));
  if(!order) return res.status(404).json({error:'Commande introuvable.'});
  const allowed=['Nouvelle','Confirmée','Expédiée','Terminée','Annulée'];
  if(!allowed.includes(req.body.status)) return res.status(400).json({error:'Statut invalide.'});
  order.status=req.body.status; writeDB(db); res.json(order);
});
app.post('/api/admin/products',adminOnly,(req,res)=>{
  const {name,category,description,price,image}=req.body||{};
  if(!clean(name)||!clean(category)||!Number(price)||!clean(image)) return res.status(400).json({error:'Champs obligatoires manquants.'});
  const db=readDB(), product={id:Date.now(),name:clean(name),category:clean(category),description:clean(description),price:Number(price),image:clean(image),featured:false};
  db.products.unshift(product); writeDB(db); res.status(201).json(product);
});
app.delete('/api/admin/products/:id',adminOnly,(req,res)=>{
  const db=readDB(); db.products=db.products.filter(p=>p.id!==Number(req.params.id)); writeDB(db); res.json({message:'Produit supprimé.'});
});
app.get('/admin',(req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Zora Design disponible sur http://localhost:${PORT}`));
