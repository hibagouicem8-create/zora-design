# Zora Design — projet recréé

Recréation indépendante de la vitrine Zora Design à partir des éléments visibles publiquement sur le site SITE123. Ce projet n'est pas une exportation du code privé SITE123 et ne contient pas les fichiers originaux, les images originales ni les éventuels contenus non publics.

## Fonctionnalités
- Site vitrine responsive en français, palette rose poudré / crème / doré.
- Univers Robes, Costumes, Caftans, Accessoires.
- Catalogue filtrable et fiches produits simplifiées.
- Panier conservé dans le navigateur.
- Formulaire de commande enregistré côté serveur.
- Inscription newsletter enregistrée côté serveur.
- Espace admin : consulter les commandes, modifier leur statut et ajouter des produits.
- Stockage de démonstration dans `data/store.json` (créé automatiquement).

## Installation
1. Installer Node.js 18 ou plus récent.
2. Décompresser le projet.
3. Dans le dossier du projet, lancer `npm install`.
4. Copier `.env.example` vers `.env`, puis changer impérativement `SESSION_SECRET`, `ADMIN_USERNAME` et `ADMIN_PASSWORD`.
5. Lancer `npm start`.
6. Ouvrir `http://localhost:3000`.
7. Administration : `http://localhost:3000/admin`.

## Configuration
- Les produits de démonstration se trouvent dans `data/store.json` après le premier lancement.
- Remplacez les URLs d'images de démonstration par vos propres photos autorisées.
- Les prix sont en dinars algériens.
- Le formulaire enregistre une demande de commande, mais aucun paiement en ligne n'est intégré.
- Pour les ventes réelles, configurez HTTPS, une base de données persistante, sauvegardes, politique de confidentialité et un vrai fournisseur de paiement adapté à votre pays.

## Important avant mise en production
Le stockage JSON convient à une maquette ou à un petit test, pas à une boutique avec plusieurs commandes simultanées. Le mot de passe admin doit être changé via `.env`. Utilisez un gestionnaire de sessions persistant et une base de données (PostgreSQL/MySQL), ajoutez validation serveur plus stricte, protection CSRF, journalisation et sauvegardes avant publication.
