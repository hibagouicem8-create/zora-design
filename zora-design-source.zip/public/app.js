const $=s=>document.querySelector(s);
let products=[], cart=JSON.parse(localStorage.getItem('zora-cart')||'[]'), activeFilter='Tous';
const money=n=>new Intl.NumberFormat('fr-DZ').format(n)+' DA';
async function loadProducts(category='Tous'){
  activeFilter=category;
  try{const r=await fetch('/api/products'+(category!=='Tous'?'?category='+encodeURIComponent(category):''));products=await r.json();renderProducts();}
  catch(e){$('#products').innerHTML='<p>Impossible de charger les produits. Vérifiez que le serveur est démarré.</p>';}
}
function renderProducts(){
  $('#products').innerHTML=products.length?products.map(p=>`<article class="product-card"><div class="product-image"><img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy"><span class="product-tag">${esc(p.category)}</span></div><div class="product-info"><h3>${esc(p.name)}</h3><p>${esc(p.description||'Une pièce sélectionnée par Zora.')}</p><div class="product-buy"><span class="price">${money(p.price)}</span><button class="add-btn" data-add="${p.id}">AJOUTER +</button></div></div></article>`).join(''):'<p>Aucun article dans cette catégorie.</p>';
}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function saveCart(){localStorage.setItem('zora-cart',JSON.stringify(cart));renderCart();}
function add(id){const p=products.find(x=>x.id===id)||allProductsCache.find(x=>x.id===id);if(!p)return;const item=cart.find(x=>x.id===id);item?item.quantity++:cart.push({id,quantity:1});saveCart();}
let allProductsCache=[];
async function initCache(){const r=await fetch('/api/products');allProductsCache=await r.json();}
function renderCart(){
 const count=cart.reduce((s,i)=>s+i.quantity,0);$('#cartCount').textContent=count;
 const rows=cart.map(i=>{const p=allProductsCache.find(x=>x.id===i.id);if(!p)return '';return `<div class="cart-row"><img src="${esc(p.image)}" alt=""><div><h4>${esc(p.name)}</h4><small>${money(p.price)}</small><div class="qty"><button data-dec="${p.id}">−</button><span>${i.quantity}</span><button data-inc="${p.id}">+</button></div></div><button class="remove" data-remove="${p.id}">×</button></div>`}).join('');
 $('#cartItems').innerHTML=rows||'<p style="color:#87777a;text-align:center;padding:45px 0">Votre panier est encore vide.</p>';
 const total=cart.reduce((s,i)=>{const p=allProductsCache.find(x=>x.id===i.id);return s+(p?p.price*i.quantity:0)},0);$('#cartTotal').textContent=money(total);
}
function openCart(){ $('#cartDrawer').classList.add('open');$('#overlay').classList.add('show');}
function closeCart(){ $('#cartDrawer').classList.remove('open');$('#overlay').classList.remove('show');}
$('#products').addEventListener('click',e=>{const b=e.target.closest('[data-add]');if(b){add(Number(b.dataset.add));openCart();}});
$('#filters').addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;document.querySelectorAll('#filters button').forEach(x=>x.classList.toggle('active',x===b));loadProducts(b.dataset.filter);});
document.querySelectorAll('.universe-card').forEach(a=>a.addEventListener('click',()=>{const f=a.dataset.filter;document.querySelectorAll('#filters button').forEach(x=>x.classList.toggle('active',x.dataset.filter===f));loadProducts(f);}));
$('#cartItems').addEventListener('click',e=>{const id=Number((e.target.dataset.inc||e.target.dataset.dec||e.target.dataset.remove));if(!id)return;const item=cart.find(x=>x.id===id);if(e.target.dataset.inc)item.quantity++;if(e.target.dataset.dec)item.quantity--;if(e.target.dataset.remove||item.quantity<=0)cart=cart.filter(x=>x.id!==id);saveCart();});
$('#openCart').onclick=openCart;$('#closeCart').onclick=closeCart;$('#overlay').onclick=closeCart;
$('#checkoutBtn').onclick=()=>{if(!cart.length)return;closeCart();$('#checkoutModal').classList.add('show');};
$('#closeCheckout').onclick=()=>$('#checkoutModal').classList.remove('show');
$('#checkoutForm').addEventListener('submit',async e=>{
 e.preventDefault();const f=new FormData(e.target),customer=Object.fromEntries(f.entries());
 const r=await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer,items:cart})});const data=await r.json();
 if(!r.ok){$('#checkoutMessage').textContent=data.error||'Erreur.';return;}
 $('#checkoutMessage').textContent='Merci ! Votre commande n°'+data.order.id+' a bien été enregistrée. Notre équipe vous contactera pour confirmation.';
 cart=[];saveCart();e.target.reset();
});
$('#newsletterForm').addEventListener('submit',async e=>{e.preventDefault();const email=new FormData(e.target).get('email');const r=await fetch('/api/newsletter',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})});const d=await r.json();$('#newsletterMessage').textContent=d.message||d.error;e.target.reset();});
$('#menuToggle').onclick=()=>$('#nav').classList.toggle('open');
initCache().then(()=>{loadProducts();renderCart();});
